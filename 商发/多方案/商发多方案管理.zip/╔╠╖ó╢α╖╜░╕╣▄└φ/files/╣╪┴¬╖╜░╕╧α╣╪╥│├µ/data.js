﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,[i,j],k,_(l,m,n,o,p,q,r,_(),s,_(t,u,v,w,x,_(y,z,A,B),C,null,D,E,F,E,G,H,I,null,J,K,L,M,N,O,P,K),Q,_(),R,_(),S,_(T,[])),U,_(),V,_());}; 
var b="url",c="关联方案相关页面.html",d="generationDate",e=new Date(1482826070418.35),f="isCanvasEnabled",g=false,h="variables",i="OnLoadVariable",j="whichseclect",k="page",l="packageId",m="59be1042205a47918129b237cd80a660",n="type",o="Axure:Page",p="name",q="关联方案相关页面",r="notes",s="style",t="baseStyle",u="627587b6038d43cca051c114ac41ad32",v="pageAlignment",w="center",x="fill",y="fillType",z="solid",A="color",B=0xFFFFFFFF,C="image",D="imageHorizontalAlignment",E="near",F="imageVerticalAlignment",G="imageRepeat",H="auto",I="favicon",J="sketchFactor",K="0",L="colorStyle",M="appliedColor",N="fontName",O="Applied Font",P="borderWidth",Q="adaptiveStyles",R="interactionMap",S="diagram",T="objects",U="masters",V="objectPaths";
return _creator();
})());